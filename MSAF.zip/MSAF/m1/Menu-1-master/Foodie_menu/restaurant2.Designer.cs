﻿namespace Foodie_menu
{
    partial class restaurant2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.slide_panel = new System.Windows.Forms.Panel();
            this.cart2_button = new System.Windows.Forms.Button();
            this.minimize_button = new System.Windows.Forms.PictureBox();
            this.review2_button = new System.Windows.Forms.Button();
            this.close_button = new System.Windows.Forms.PictureBox();
            this.favorites2_button = new System.Windows.Forms.Button();
            this.homeFood2_button = new System.Windows.Forms.Button();
            this.exclusive2_button = new System.Windows.Forms.Button();
            this.home2_button = new System.Windows.Forms.Button();
            this.cart21 = new Foodie_menu.cart2();
            this.favorite21 = new Foodie_menu.favorite2();
            this.review21 = new Foodie_menu.review2();
            this.homeFood21 = new Foodie_menu.homeFood2();
            this.exclusive21 = new Foodie_menu.exclusive2();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minimize_button)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.close_button)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.slide_panel);
            this.panel1.Controls.Add(this.cart2_button);
            this.panel1.Controls.Add(this.minimize_button);
            this.panel1.Controls.Add(this.review2_button);
            this.panel1.Controls.Add(this.close_button);
            this.panel1.Controls.Add(this.favorites2_button);
            this.panel1.Controls.Add(this.homeFood2_button);
            this.panel1.Controls.Add(this.exclusive2_button);
            this.panel1.Controls.Add(this.home2_button);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(941, 63);
            this.panel1.TabIndex = 0;
            // 
            // slide_panel
            // 
            this.slide_panel.BackColor = System.Drawing.Color.White;
            this.slide_panel.Location = new System.Drawing.Point(0, 0);
            this.slide_panel.Name = "slide_panel";
            this.slide_panel.Size = new System.Drawing.Size(112, 6);
            this.slide_panel.TabIndex = 6;
            // 
            // cart2_button
            // 
            this.cart2_button.BackColor = System.Drawing.Color.Gold;
            this.cart2_button.FlatAppearance.BorderSize = 0;
            this.cart2_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cart2_button.Image = global::Foodie_menu.Resource1.cart1;
            this.cart2_button.Location = new System.Drawing.Point(838, 20);
            this.cart2_button.Margin = new System.Windows.Forms.Padding(0);
            this.cart2_button.Name = "cart2_button";
            this.cart2_button.Size = new System.Drawing.Size(51, 43);
            this.cart2_button.TabIndex = 5;
            this.cart2_button.UseVisualStyleBackColor = false;
            this.cart2_button.Click += new System.EventHandler(this.button1_Click);
            // 
            // minimize_button
            // 
            this.minimize_button.Image = global::Foodie_menu.Resource1.minimize;
            this.minimize_button.Location = new System.Drawing.Point(905, 0);
            this.minimize_button.Margin = new System.Windows.Forms.Padding(0);
            this.minimize_button.Name = "minimize_button";
            this.minimize_button.Size = new System.Drawing.Size(18, 20);
            this.minimize_button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.minimize_button.TabIndex = 2;
            this.minimize_button.TabStop = false;
            this.minimize_button.Click += new System.EventHandler(this.minimize_button_Click);
            // 
            // review2_button
            // 
            this.review2_button.FlatAppearance.BorderSize = 0;
            this.review2_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.review2_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.review2_button.ForeColor = System.Drawing.Color.White;
            this.review2_button.Image = global::Foodie_menu.Resource1.inspection;
            this.review2_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.review2_button.Location = new System.Drawing.Point(504, 0);
            this.review2_button.Name = "review2_button";
            this.review2_button.Size = new System.Drawing.Size(107, 63);
            this.review2_button.TabIndex = 4;
            this.review2_button.Text = " Review";
            this.review2_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.review2_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.review2_button.UseVisualStyleBackColor = true;
            this.review2_button.Click += new System.EventHandler(this.review2_button_Click);
            // 
            // close_button
            // 
            this.close_button.Image = global::Foodie_menu.Resource1.close;
            this.close_button.Location = new System.Drawing.Point(923, 0);
            this.close_button.Margin = new System.Windows.Forms.Padding(0);
            this.close_button.Name = "close_button";
            this.close_button.Size = new System.Drawing.Size(18, 20);
            this.close_button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.close_button.TabIndex = 1;
            this.close_button.TabStop = false;
            this.close_button.Click += new System.EventHandler(this.close_button_Click);
            // 
            // favorites2_button
            // 
            this.favorites2_button.FlatAppearance.BorderSize = 0;
            this.favorites2_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.favorites2_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.favorites2_button.ForeColor = System.Drawing.Color.White;
            this.favorites2_button.Image = global::Foodie_menu.Resource1.star;
            this.favorites2_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.favorites2_button.Location = new System.Drawing.Point(376, 0);
            this.favorites2_button.Name = "favorites2_button";
            this.favorites2_button.Size = new System.Drawing.Size(122, 63);
            this.favorites2_button.TabIndex = 3;
            this.favorites2_button.Text = " Favorites";
            this.favorites2_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.favorites2_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.favorites2_button.UseVisualStyleBackColor = true;
            this.favorites2_button.Click += new System.EventHandler(this.favorites2_button_Click);
            // 
            // homeFood2_button
            // 
            this.homeFood2_button.FlatAppearance.BorderSize = 0;
            this.homeFood2_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.homeFood2_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeFood2_button.ForeColor = System.Drawing.Color.White;
            this.homeFood2_button.Image = global::Foodie_menu.Resource1.special;
            this.homeFood2_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.homeFood2_button.Location = new System.Drawing.Point(245, 0);
            this.homeFood2_button.Name = "homeFood2_button";
            this.homeFood2_button.Size = new System.Drawing.Size(125, 63);
            this.homeFood2_button.TabIndex = 2;
            this.homeFood2_button.Text = " Speciality";
            this.homeFood2_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.homeFood2_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.homeFood2_button.UseVisualStyleBackColor = true;
            this.homeFood2_button.Click += new System.EventHandler(this.homeFood2_button_Click);
            // 
            // exclusive2_button
            // 
            this.exclusive2_button.FlatAppearance.BorderSize = 0;
            this.exclusive2_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exclusive2_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exclusive2_button.ForeColor = System.Drawing.Color.White;
            this.exclusive2_button.Image = global::Foodie_menu.Resource1.membership;
            this.exclusive2_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.exclusive2_button.Location = new System.Drawing.Point(118, 0);
            this.exclusive2_button.Name = "exclusive2_button";
            this.exclusive2_button.Size = new System.Drawing.Size(121, 63);
            this.exclusive2_button.TabIndex = 1;
            this.exclusive2_button.Text = "Exclusive";
            this.exclusive2_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.exclusive2_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.exclusive2_button.UseVisualStyleBackColor = true;
            this.exclusive2_button.Click += new System.EventHandler(this.button2_Click);
            // 
            // home2_button
            // 
            this.home2_button.FlatAppearance.BorderSize = 0;
            this.home2_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.home2_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.home2_button.ForeColor = System.Drawing.Color.White;
            this.home2_button.Image = global::Foodie_menu.Resource1.homem2;
            this.home2_button.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.home2_button.Location = new System.Drawing.Point(0, 3);
            this.home2_button.Name = "home2_button";
            this.home2_button.Size = new System.Drawing.Size(112, 63);
            this.home2_button.TabIndex = 0;
            this.home2_button.Text = " Home";
            this.home2_button.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.home2_button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.home2_button.UseVisualStyleBackColor = true;
            this.home2_button.Click += new System.EventHandler(this.home2_button_Click);
            // 
            // cart21
            // 
            this.cart21.BackColor = System.Drawing.Color.White;
            this.cart21.Location = new System.Drawing.Point(701, 63);
            this.cart21.Name = "cart21";
            this.cart21.Size = new System.Drawing.Size(240, 476);
            this.cart21.TabIndex = 4;
            // 
            // favorite21
            // 
            this.favorite21.BackColor = System.Drawing.Color.White;
            this.favorite21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.favorite21.Location = new System.Drawing.Point(0, 0);
            this.favorite21.Margin = new System.Windows.Forms.Padding(0);
            this.favorite21.Name = "favorite21";
            this.favorite21.Size = new System.Drawing.Size(941, 539);
            this.favorite21.TabIndex = 6;
            // 
            // review21
            // 
            this.review21.BackColor = System.Drawing.Color.White;
            this.review21.Location = new System.Drawing.Point(0, 63);
            this.review21.Name = "review21";
            this.review21.Size = new System.Drawing.Size(941, 476);
            this.review21.TabIndex = 6;
            this.review21.Load += new System.EventHandler(this.review21_Load);
            // 
            // homeFood21
            // 
            this.homeFood21.AutoScroll = true;
            this.homeFood21.Location = new System.Drawing.Point(0, 63);
            this.homeFood21.Name = "homeFood21";
            this.homeFood21.Size = new System.Drawing.Size(941, 473);
            this.homeFood21.TabIndex = 3;
            // 
            // exclusive21
            // 
            this.exclusive21.AutoScroll = true;
            this.exclusive21.Location = new System.Drawing.Point(0, 63);
            this.exclusive21.Name = "exclusive21";
            this.exclusive21.Size = new System.Drawing.Size(941, 473);
            this.exclusive21.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Foodie_menu.Resource1.delivery_24px2;
            this.pictureBox1.Location = new System.Drawing.Point(795, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(52, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // restaurant2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cart21);
            this.Controls.Add(this.favorite21);
            this.Controls.Add(this.review21);
            this.Controls.Add(this.homeFood21);
            this.Controls.Add(this.exclusive21);
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "restaurant2";
            this.Size = new System.Drawing.Size(941, 539);
            this.Load += new System.EventHandler(this.restaurant2_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.minimize_button)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.close_button)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button review2_button;
        private System.Windows.Forms.Button favorites2_button;
        private System.Windows.Forms.Button homeFood2_button;
        private System.Windows.Forms.Button exclusive2_button;
        private System.Windows.Forms.Button home2_button;
        private System.Windows.Forms.PictureBox minimize_button;
        private System.Windows.Forms.PictureBox close_button;
        private exclusive2 exclusive21;
        private homeFood2 homeFood21;
        private System.Windows.Forms.Button cart2_button;
        private cart2 cart21;
        private review2 review21;
        private favorite2 favorite21;
        private System.Windows.Forms.Panel slide_panel;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
