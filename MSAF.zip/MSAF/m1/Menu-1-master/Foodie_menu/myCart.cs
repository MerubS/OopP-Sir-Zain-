﻿using System.Linq.Expressions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Runtime.Serialization.Formatters.Binary;
namespace Foodie_menu
{
                      ///////////////////////////      Cart For Foodie Hub        ///////////////////
    public class myCart
    {

        public static string[] items = new string[21];      // Array to store items in cart (max 20 items)
        public static int index1 = 0;                       // Variable to store number of items in cart (array index based)

        public static string[] favorites = new string[11];  // Array to store items in favorites (max 10 items)
        public static int index2 = 0;                       // Variable to store numbert of favorite items( array index based)
        public static int bill = 0;                         // Variable to store bill amount

        private static int[] myReview = new int[10];        // Int Array to store customer Rating ( 1 to 5)
        private static int[] Reviews = new int[10];         // Int Array to store universal Rating (SUM)

        static int customers;                               // Stores number of customers who submitted reviews
        static int customer_id;                             // Stores customer ID from database
        static string coupon;                                      // Stores the valid coupon code

                       
        public myCart() { }// Constructor---- DEFAULT

        public myCart(string[] fav, int[] myRev, int id)           // Constructor To initialiaze favorites and reviews from database
        {
           favorites = fav;

            myReview = myRev;
            customer_id = id;

            foreach (string x in favorites)                           // Length of string
            {
                if( x == " ")
                {
                    continue;
                }

                if (x == "Pizza" || x == "Burger" || x == "Pasta" || x == "Sandwhich" || x == "French Fries" || x == "Pulao" || x == "Daal Mix" || x == "Chicken Roast" || x == "Mutton Karahi" || x == "Haleem")
                {
                    index2++;
                }
                
            }
            index2++;

            if (index2 == 1) { index2 = 0; }
        }

        

        public void review_updater() {                                            // SYNCS universal reviews to Review array 
            using (StreamReader file = new StreamReader("Review.txt"))
            {
                for (int i = 0; i < 10; i++)
                    Reviews[i] = int.Parse(file.ReadLine());

                customers = int.Parse(file.ReadLine());                        // Gets number of customers who submitted reviews
            }
        }       


        public void file_updater()                      // Updates file contents whenever a review is submitted
        {
            customers++;

            for (int i = 0; i < 10; i++)
            {
                Reviews[i] += myReview[i];                  
            }

            using (StreamWriter file = new StreamWriter("Review.txt"))
            {
                foreach (var x in Reviews)
                    file.WriteLine(x.ToString());


                file.WriteLine(customers.ToString());
            }
        }

                                                          // Update Favourites and Reviews // 
        public void savingData ()
        {
            
            BinaryFormatter f = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            f.Serialize(ms, favorites);
            byte[] bi = ms.ToArray();
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\zahid\source\repos\Project.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
           
                SqlCommand comm = new SqlCommand();
                comm.CommandText = "update [useraccount] SET ffavourites = @fav where UID = @val ";
            comm.Parameters.AddWithValue("@val", customer_id);
            comm.Connection = con;
                comm.Parameters.AddWithValue("@fav", bi);
                int i = comm.ExecuteNonQuery();
                if (i > 0)
                {
                Console.WriteLine("Favorites updated for FoodieHub");
                }
                con.Close();
                MemoryStream mb = new MemoryStream();
                f.Serialize(mb, myReview);
                byte[] by = mb.ToArray();
                con.Open();
                comm.CommandText = "update [useraccount] SET freview = @rev where UID = @val ";
                comm.Connection = con;
                comm.Parameters.AddWithValue("@rev", by);
                int m = comm.ExecuteNonQuery();
                if (m > 0)
                {
                Console.WriteLine("Reviews updated for FoodieHub");
                }
                con.Close();
            
        }

                                                       ///////////////// Setter / Getters For Item Rating // /////////////
        
        public void SET_myReview(int index, int rating) {    /// Sets rating for an item in index sequence
            myReview[index] = rating;
        }

        public int GET_myReview(int index)                /// Gets customer rating for an item in index sequence
        {
            return myReview[index];
        }

        public int GET_Reviews(int index)                /// Gets Universal Rating for an item in index sequence
        {
            
            try
            {
                int rating = Reviews[index] / customers;   /// Performs average calculation
                return rating;
            }
            catch
            {
                return 1;
            }
            
        }
        public void couponset(string a)           // Setter for coupon value
        {                                     

            coupon = a;

        }

        public string getcoupon()                 // Getter for coupon
        {
            return coupon;
        }

        public int _bill {                     // Getter Function For Bill
            get { return bill; }
         }

        

                 /////////////////////   Function To Remove Item From Cart ///////////////////
        public void removeItem(string item)                 //// Item To be deleted gets passed as parameter ////
        {
            int k = 0;

            foreach (string s in items)           
            {
                if (item == s)
                {

                    switch (item)                    ///// Remove Deleted item Price From Bill//////////
                    {
                        case "Pizza":
                            bill -= 1500; break;
                        case "Burger":
                            bill -= 1000; break;
                        case "Pasta":
                            bill -= 600; break;
                        case "Sandwhich":
                            bill -= 300; break;
                        case "French Fries":
                            bill -= 200; break;
                        case "Pulao":
                            bill -= 250; break;
                        case "Daal Mix":
                            bill -= 150; break;
                        case "Chicken Roast":
                            bill -= 300; break;
                        case "Mutton Karahi":
                            bill -= 500; break;
                        case "Haleem":
                            bill -= 200; break;

                        default: MessageBox.Show("Item Not Found"); break;
                    }


                    break;
                }
                k++;
            }

            while (k < index1)        ////// Shifts elements in the array after an item is deleted
            {
                
                items[k] = items[k + 1];
                k++;
            }
            index1--;                         //// Reduces index as one item is removed
        }



        //////////////////////// Function To Remove an item From favorites ////////////////////
        ///
        public void removeFavorite(string fav)            //// Items that needs to be deleted gets passed as a paramater

        {

            int k = 0;
            foreach(string favo in favorites)
            {

                if (fav == favo)                 //// Finds the index of the item to be removed
                {
                    break;
                }
                k++;

            }

            while (k < index2)              //// Shifts items after an item gets deleted
            {
                favorites[k] = favorites[k + 1];
                k++;
            }
            
            index2--;                        // Reduces array index as an item gets removed

        }


        /////////////////////// Function To add item in Cart ///////////////////
        ///
        public void addItem(String item)      //// Item to add gets passed as a string parameter
        {
            
            if (index1 < 20)               // Checks that items in cart are no more than 20
            {

                items[index1++] = item;

                switch (item)               /// Adds the price of item in the bill
                {
                    case "Pizza":
                        bill += 1500; break;
                    case "Burger":
                        bill += 1000; break;
                    case "Pasta":
                        bill += 600; break;
                    case "Sandwhich":
                        bill += 300; break;
                    case "French Fries":
                        bill += 200; break;
                    case "Pulao":
                        bill += 250; break;
                    case "Daal Mix":
                        bill += 150; break;
                    case "Chicken Roast":
                        bill += 300; break;
                    case "Mutton Karahi":
                        bill += 500; break;
                    case "Haleem":
                        bill += 200; break;

                    default: MessageBox.Show("Item Not Found"); break;
                }
            }
            else              /// If items are more than 20 a Message is displayed indicating "cart is full"
            {
                MessageBox.Show("You Can't Add More Than 20 Items To Your Cart","Cart Full",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }

        }


        //////////////////////// Function to add an item to favorites /////////////////////
        ///

        public void addFavorite(string fav)       /// Item to be deleted gets passed as string parameter
        {
            if (index2 < 10)                       /// No more than 10 items can be added to favorites
            {
                bool x = true;                       ///  Flag to indicate if item can be added or not (duplication check)
                foreach (string favo in favorites)
                {
                    if (fav == favo)        // Checks that items in favorites dont get duplictaed
                    {
                        x = false;
                        break;
                    }
                    else
                    {
                        x = true;              // Used to grants permission to add item in favorites
                    }
                }
                if (x)
                {
                    favorites[index2++] = fav;           // Adds item to favorites
                    
                }
            }

            else             /// A message gets displayed indicating " MAX 10 items can be added to favorites
            {
                MessageBox.Show("You Can't Add More Than 10 Items To Your Favorites", "Favorites", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }



    }
}
