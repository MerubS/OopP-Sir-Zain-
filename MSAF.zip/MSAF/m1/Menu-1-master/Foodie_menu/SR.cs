﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class SR : Form
    {
        public SR()
        {
            InitializeComponent();
      

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       

       

        private void restaurant21_Load(object sender, EventArgs e)
        {

        }
    }
}
