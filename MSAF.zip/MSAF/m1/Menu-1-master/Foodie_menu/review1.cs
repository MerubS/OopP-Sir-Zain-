﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Foodie_menu
{
    public partial class review1 : UserControl
    {
        myCart obj = new myCart();
        public review1()
        {
            InitializeComponent();

            pizza_Rating.Value = obj.GET_myReview(0);
            pasta_Rating.Value = obj.GET_myReview(1);
            sandwhich_Rating.Value = obj.GET_myReview(2);
            burger_Rating.Value = obj.GET_myReview(3);
            fries_Rating.Value = obj.GET_myReview(4);
            pulao_Rating.Value = obj.GET_myReview(5);
            daal_Rating.Value = obj.GET_myReview(6);
            roast_Rating.Value = obj.GET_myReview(7);
            karahi_Rating.Value = obj.GET_myReview(8);
            haleem_Rating.Value = obj.GET_myReview(9);
        }

        public void work()
        {
            pizza_Rating.Value = obj.GET_myReview(0);
            pasta_Rating.Value = obj.GET_myReview(1);
            sandwhich_Rating.Value = obj.GET_myReview(2);
            burger_Rating.Value = obj.GET_myReview(3);
            fries_Rating.Value = obj.GET_myReview(4);
            pulao_Rating.Value = obj.GET_myReview(5);
            daal_Rating.Value = obj.GET_myReview(6);
            roast_Rating.Value = obj.GET_myReview(7);
            karahi_Rating.Value =  obj.GET_myReview(8);
            haleem_Rating.Value = obj.GET_myReview(9);
        }

        private void submit_button_Click(object sender, EventArgs e)
        {
            obj.SET_myReview(0, pizza_Rating.Value);
            obj.SET_myReview(1, pasta_Rating.Value);
            obj.SET_myReview(2, sandwhich_Rating.Value);
            obj.SET_myReview(3, burger_Rating.Value);
            obj.SET_myReview(4, fries_Rating.Value);
            obj.SET_myReview(5, pulao_Rating.Value);
            obj.SET_myReview(6, daal_Rating.Value);
            obj.SET_myReview(7, roast_Rating.Value);
            obj.SET_myReview(8, karahi_Rating.Value);
            obj.SET_myReview(9, haleem_Rating.Value);

            obj.file_updater();

            submit_label.Visible = true;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (submit_label.Visible) {
                submit_label.Visible = false;
                timer1.Stop();
             }
        }
    }
}
