﻿namespace Foodie_menu
{
    partial class review1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.submit_label = new System.Windows.Forms.Label();
            this.submit_button = new System.Windows.Forms.Button();
            this.haleem_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.karahi_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.roast_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.daal_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.pulao_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.fries_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.burger_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.sandwhich_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.pasta_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.pizza_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.submit_label);
            this.panel1.Controls.Add(this.submit_button);
            this.panel1.Controls.Add(this.haleem_Rating);
            this.panel1.Controls.Add(this.karahi_Rating);
            this.panel1.Controls.Add(this.roast_Rating);
            this.panel1.Controls.Add(this.daal_Rating);
            this.panel1.Controls.Add(this.pulao_Rating);
            this.panel1.Controls.Add(this.fries_Rating);
            this.panel1.Controls.Add(this.burger_Rating);
            this.panel1.Controls.Add(this.sandwhich_Rating);
            this.panel1.Controls.Add(this.pasta_Rating);
            this.panel1.Controls.Add(this.pizza_Rating);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(26, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(886, 415);
            this.panel1.TabIndex = 0;
            // 
            // submit_label
            // 
            this.submit_label.AutoSize = true;
            this.submit_label.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submit_label.ForeColor = System.Drawing.Color.Cyan;
            this.submit_label.Location = new System.Drawing.Point(290, 378);
            this.submit_label.Name = "submit_label";
            this.submit_label.Size = new System.Drawing.Size(346, 37);
            this.submit_label.TabIndex = 22;
            this.submit_label.Text = "Response Recorded Thank You!";
            this.submit_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.submit_label.Visible = false;
            // 
            // submit_button
            // 
            this.submit_button.BackColor = System.Drawing.Color.Transparent;
            this.submit_button.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submit_button.Location = new System.Drawing.Point(382, 344);
            this.submit_button.Name = "submit_button";
            this.submit_button.Size = new System.Drawing.Size(149, 31);
            this.submit_button.TabIndex = 21;
            this.submit_button.Text = "Submit";
            this.submit_button.UseVisualStyleBackColor = false;
            this.submit_button.Click += new System.EventHandler(this.submit_button_Click);
            // 
            // haleem_Rating
            // 
            this.haleem_Rating.BackColor = System.Drawing.Color.Transparent;
            this.haleem_Rating.ForeColor = System.Drawing.Color.Gold;
            this.haleem_Rating.Location = new System.Drawing.Point(625, 287);
            this.haleem_Rating.Name = "haleem_Rating";
            this.haleem_Rating.Size = new System.Drawing.Size(235, 36);
            this.haleem_Rating.TabIndex = 20;
            this.haleem_Rating.Value = 0;
            // 
            // karahi_Rating
            // 
            this.karahi_Rating.BackColor = System.Drawing.Color.Transparent;
            this.karahi_Rating.ForeColor = System.Drawing.Color.Gold;
            this.karahi_Rating.Location = new System.Drawing.Point(625, 232);
            this.karahi_Rating.Name = "karahi_Rating";
            this.karahi_Rating.Size = new System.Drawing.Size(235, 36);
            this.karahi_Rating.TabIndex = 19;
            this.karahi_Rating.Value = 0;
            // 
            // roast_Rating
            // 
            this.roast_Rating.BackColor = System.Drawing.Color.Transparent;
            this.roast_Rating.ForeColor = System.Drawing.Color.Gold;
            this.roast_Rating.Location = new System.Drawing.Point(625, 178);
            this.roast_Rating.Name = "roast_Rating";
            this.roast_Rating.Size = new System.Drawing.Size(235, 36);
            this.roast_Rating.TabIndex = 18;
            this.roast_Rating.Value = 0;
            // 
            // daal_Rating
            // 
            this.daal_Rating.BackColor = System.Drawing.Color.Transparent;
            this.daal_Rating.ForeColor = System.Drawing.Color.Gold;
            this.daal_Rating.Location = new System.Drawing.Point(625, 124);
            this.daal_Rating.Name = "daal_Rating";
            this.daal_Rating.Size = new System.Drawing.Size(235, 36);
            this.daal_Rating.TabIndex = 17;
            this.daal_Rating.Value = 0;
            // 
            // pulao_Rating
            // 
            this.pulao_Rating.BackColor = System.Drawing.Color.Transparent;
            this.pulao_Rating.ForeColor = System.Drawing.Color.Gold;
            this.pulao_Rating.Location = new System.Drawing.Point(625, 68);
            this.pulao_Rating.Name = "pulao_Rating";
            this.pulao_Rating.Size = new System.Drawing.Size(235, 36);
            this.pulao_Rating.TabIndex = 16;
            this.pulao_Rating.Value = 0;
            // 
            // fries_Rating
            // 
            this.fries_Rating.BackColor = System.Drawing.Color.Transparent;
            this.fries_Rating.ForeColor = System.Drawing.Color.Gold;
            this.fries_Rating.Location = new System.Drawing.Point(190, 289);
            this.fries_Rating.Name = "fries_Rating";
            this.fries_Rating.Size = new System.Drawing.Size(235, 36);
            this.fries_Rating.TabIndex = 15;
            this.fries_Rating.Value = 0;
            // 
            // burger_Rating
            // 
            this.burger_Rating.BackColor = System.Drawing.Color.Transparent;
            this.burger_Rating.ForeColor = System.Drawing.Color.Gold;
            this.burger_Rating.Location = new System.Drawing.Point(190, 234);
            this.burger_Rating.Name = "burger_Rating";
            this.burger_Rating.Size = new System.Drawing.Size(235, 36);
            this.burger_Rating.TabIndex = 14;
            this.burger_Rating.Value = 0;
            // 
            // sandwhich_Rating
            // 
            this.sandwhich_Rating.BackColor = System.Drawing.Color.Transparent;
            this.sandwhich_Rating.ForeColor = System.Drawing.Color.Gold;
            this.sandwhich_Rating.Location = new System.Drawing.Point(190, 179);
            this.sandwhich_Rating.Name = "sandwhich_Rating";
            this.sandwhich_Rating.Size = new System.Drawing.Size(235, 36);
            this.sandwhich_Rating.TabIndex = 13;
            this.sandwhich_Rating.Value = 0;
            // 
            // pasta_Rating
            // 
            this.pasta_Rating.BackColor = System.Drawing.Color.Transparent;
            this.pasta_Rating.ForeColor = System.Drawing.Color.Gold;
            this.pasta_Rating.Location = new System.Drawing.Point(190, 125);
            this.pasta_Rating.Name = "pasta_Rating";
            this.pasta_Rating.Size = new System.Drawing.Size(235, 36);
            this.pasta_Rating.TabIndex = 12;
            this.pasta_Rating.Value = 0;
            // 
            // pizza_Rating
            // 
            this.pizza_Rating.BackColor = System.Drawing.Color.Transparent;
            this.pizza_Rating.ForeColor = System.Drawing.Color.Gold;
            this.pizza_Rating.Location = new System.Drawing.Point(190, 69);
            this.pizza_Rating.Name = "pizza_Rating";
            this.pizza_Rating.Size = new System.Drawing.Size(235, 36);
            this.pizza_Rating.TabIndex = 11;
            this.pizza_Rating.Value = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(445, 287);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 37);
            this.label11.TabIndex = 10;
            this.label11.Text = "Haleem";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(445, 232);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(174, 37);
            this.label10.TabIndex = 9;
            this.label10.Text = "Mutton Karahi";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(445, 178);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(165, 37);
            this.label9.TabIndex = 8;
            this.label9.Text = "Chicken Roast";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(445, 124);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 37);
            this.label8.TabIndex = 7;
            this.label8.Text = "Mix Daal";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(445, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 37);
            this.label7.TabIndex = 6;
            this.label7.Text = "Pulao";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(16, 289);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(146, 37);
            this.label6.TabIndex = 5;
            this.label6.Text = "French Fries";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(16, 234);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 37);
            this.label5.TabIndex = 4;
            this.label5.Text = "Burger";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(16, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 37);
            this.label4.TabIndex = 3;
            this.label4.Text = "Sandwhich";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(16, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 37);
            this.label3.TabIndex = 2;
            this.label3.Text = "Pasta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(16, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "Pizza";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(371, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "My Reviews";
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 100;
            this.bunifuElipse1.TargetControl = this.panel1;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // review1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel1);
            this.Name = "review1";
            this.Size = new System.Drawing.Size(941, 476);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuRating haleem_Rating;
        private Bunifu.Framework.UI.BunifuRating karahi_Rating;
        private Bunifu.Framework.UI.BunifuRating roast_Rating;
        private Bunifu.Framework.UI.BunifuRating daal_Rating;
        private Bunifu.Framework.UI.BunifuRating pulao_Rating;
        private Bunifu.Framework.UI.BunifuRating fries_Rating;
        private Bunifu.Framework.UI.BunifuRating burger_Rating;
        private Bunifu.Framework.UI.BunifuRating sandwhich_Rating;
        private Bunifu.Framework.UI.BunifuRating pasta_Rating;
        private Bunifu.Framework.UI.BunifuRating pizza_Rating;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button submit_button;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Label submit_label;
        private System.Windows.Forms.Timer timer1;
    }
}
