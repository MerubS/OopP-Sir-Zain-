﻿namespace Foodie_menu
{
    partial class homeFood1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(homeFood1));
            this.panel2 = new System.Windows.Forms.Panel();
            this.pulao_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.pulaoFav_button = new System.Windows.Forms.Button();
            this.L_1 = new System.Windows.Forms.Label();
            this.flag_1 = new System.Windows.Forms.Label();
            this.pulao_buttton = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.karahi_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.L_4 = new System.Windows.Forms.Label();
            this.flag_4 = new System.Windows.Forms.Label();
            this.karahiFav_button = new System.Windows.Forms.Button();
            this.karahi_button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.daal_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.L_2 = new System.Windows.Forms.Label();
            this.flag_2 = new System.Windows.Forms.Label();
            this.daalFav_button = new System.Windows.Forms.Button();
            this.daal_button = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.roast_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.L_3 = new System.Windows.Forms.Label();
            this.flag_3 = new System.Windows.Forms.Label();
            this.roastFav_button = new System.Windows.Forms.Button();
            this.roast_button = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.haleem_Rating = new Bunifu.Framework.UI.BunifuRating();
            this.L_5 = new System.Windows.Forms.Label();
            this.flag_5 = new System.Windows.Forms.Label();
            this.haleemFav_button = new System.Windows.Forms.Button();
            this.haleem_button = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.pulao_Rating);
            this.panel2.Controls.Add(this.pulaoFav_button);
            this.panel2.Controls.Add(this.L_1);
            this.panel2.Controls.Add(this.flag_1);
            this.panel2.Controls.Add(this.pulao_buttton);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(856, 203);
            this.panel2.TabIndex = 4;
            // 
            // pulao_Rating
            // 
            this.pulao_Rating.BackColor = System.Drawing.Color.Transparent;
            this.pulao_Rating.Enabled = false;
            this.pulao_Rating.ForeColor = System.Drawing.Color.Yellow;
            this.pulao_Rating.Location = new System.Drawing.Point(388, 28);
            this.pulao_Rating.Name = "pulao_Rating";
            this.pulao_Rating.Size = new System.Drawing.Size(170, 26);
            this.pulao_Rating.TabIndex = 13;
            this.pulao_Rating.Value = 0;
            // 
            // pulaoFav_button
            // 
            this.pulaoFav_button.BackColor = System.Drawing.Color.White;
            this.pulaoFav_button.FlatAppearance.BorderSize = 0;
            this.pulaoFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pulaoFav_button.Image = ((System.Drawing.Image)(resources.GetObject("pulaoFav_button.Image")));
            this.pulaoFav_button.Location = new System.Drawing.Point(15, 0);
            this.pulaoFav_button.Margin = new System.Windows.Forms.Padding(0);
            this.pulaoFav_button.Name = "pulaoFav_button";
            this.pulaoFav_button.Size = new System.Drawing.Size(39, 33);
            this.pulaoFav_button.TabIndex = 12;
            this.pulaoFav_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.pulaoFav_button.UseVisualStyleBackColor = false;
            this.pulaoFav_button.Click += new System.EventHandler(this.pulaoFav_button_Click_1);
            // 
            // L_1
            // 
            this.L_1.AutoSize = true;
            this.L_1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_1.ForeColor = System.Drawing.Color.Red;
            this.L_1.Location = new System.Drawing.Point(694, 134);
            this.L_1.Name = "L_1";
            this.L_1.Size = new System.Drawing.Size(131, 15);
            this.L_1.TabIndex = 11;
            this.L_1.Text = " Added To Favorites!";
            this.L_1.Visible = false;
            // 
            // flag_1
            // 
            this.flag_1.AutoSize = true;
            this.flag_1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_1.ForeColor = System.Drawing.Color.Red;
            this.flag_1.Location = new System.Drawing.Point(677, 114);
            this.flag_1.Name = "flag_1";
            this.flag_1.Size = new System.Drawing.Size(166, 20);
            this.flag_1.TabIndex = 10;
            this.flag_1.Text = "Item Added To Cart!";
            this.flag_1.Visible = false;
            // 
            // pulao_buttton
            // 
            this.pulao_buttton.BackColor = System.Drawing.Color.White;
            this.pulao_buttton.FlatAppearance.BorderSize = 0;
            this.pulao_buttton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pulao_buttton.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pulao_buttton.ForeColor = System.Drawing.Color.Gold;
            this.pulao_buttton.Location = new System.Drawing.Point(713, 22);
            this.pulao_buttton.Name = "pulao_buttton";
            this.pulao_buttton.Size = new System.Drawing.Size(130, 35);
            this.pulao_buttton.TabIndex = 8;
            this.pulao_buttton.Text = "Add To Cart";
            this.pulao_buttton.UseVisualStyleBackColor = false;
            this.pulao_buttton.Click += new System.EventHandler(this.pulao_buttton_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(731, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 30);
            this.label8.TabIndex = 7;
            this.label8.Text = "Rs. 250";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(299, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 35);
            this.label3.TabIndex = 6;
            this.label3.Text = "Pulao";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::Foodie_menu.Resource1.pulao;
            this.pictureBox2.Location = new System.Drawing.Point(73, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(220, 157);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.karahi_Rating);
            this.panel1.Controls.Add(this.L_4);
            this.panel1.Controls.Add(this.flag_4);
            this.panel1.Controls.Add(this.karahiFav_button);
            this.panel1.Controls.Add(this.karahi_button);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 203);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(856, 203);
            this.panel1.TabIndex = 5;
            // 
            // karahi_Rating
            // 
            this.karahi_Rating.BackColor = System.Drawing.Color.Transparent;
            this.karahi_Rating.Enabled = false;
            this.karahi_Rating.ForeColor = System.Drawing.Color.Yellow;
            this.karahi_Rating.Location = new System.Drawing.Point(508, 29);
            this.karahi_Rating.Name = "karahi_Rating";
            this.karahi_Rating.Size = new System.Drawing.Size(170, 26);
            this.karahi_Rating.TabIndex = 13;
            this.karahi_Rating.Value = 0;
            // 
            // L_4
            // 
            this.L_4.AutoSize = true;
            this.L_4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_4.ForeColor = System.Drawing.Color.Red;
            this.L_4.Location = new System.Drawing.Point(694, 130);
            this.L_4.Name = "L_4";
            this.L_4.Size = new System.Drawing.Size(131, 15);
            this.L_4.TabIndex = 12;
            this.L_4.Text = " Added To Favorites!";
            this.L_4.Visible = false;
            // 
            // flag_4
            // 
            this.flag_4.AutoSize = true;
            this.flag_4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_4.ForeColor = System.Drawing.Color.Red;
            this.flag_4.Location = new System.Drawing.Point(677, 110);
            this.flag_4.Name = "flag_4";
            this.flag_4.Size = new System.Drawing.Size(166, 20);
            this.flag_4.TabIndex = 11;
            this.flag_4.Text = "Item Added To Cart!";
            this.flag_4.Visible = false;
            // 
            // karahiFav_button
            // 
            this.karahiFav_button.BackColor = System.Drawing.Color.White;
            this.karahiFav_button.FlatAppearance.BorderSize = 0;
            this.karahiFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.karahiFav_button.Image = ((System.Drawing.Image)(resources.GetObject("karahiFav_button.Image")));
            this.karahiFav_button.Location = new System.Drawing.Point(15, 0);
            this.karahiFav_button.Margin = new System.Windows.Forms.Padding(0);
            this.karahiFav_button.Name = "karahiFav_button";
            this.karahiFav_button.Size = new System.Drawing.Size(39, 33);
            this.karahiFav_button.TabIndex = 10;
            this.karahiFav_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.karahiFav_button.UseVisualStyleBackColor = false;
            this.karahiFav_button.Click += new System.EventHandler(this.karahiFav_button_Click);
            // 
            // karahi_button
            // 
            this.karahi_button.BackColor = System.Drawing.Color.White;
            this.karahi_button.FlatAppearance.BorderSize = 0;
            this.karahi_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.karahi_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.karahi_button.ForeColor = System.Drawing.Color.Gold;
            this.karahi_button.Location = new System.Drawing.Point(713, 25);
            this.karahi_button.Name = "karahi_button";
            this.karahi_button.Size = new System.Drawing.Size(130, 35);
            this.karahi_button.TabIndex = 8;
            this.karahi_button.Text = "Add To Cart";
            this.karahi_button.UseVisualStyleBackColor = false;
            this.karahi_button.Click += new System.EventHandler(this.karahi_button_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(731, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 30);
            this.label2.TabIndex = 7;
            this.label2.Text = "Rs. 500";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(299, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 35);
            this.label4.TabIndex = 6;
            this.label4.Text = "Mutton Karahi";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::Foodie_menu.Resource1.karahi;
            this.pictureBox1.Location = new System.Drawing.Point(73, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(220, 157);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.daal_Rating);
            this.panel3.Controls.Add(this.L_2);
            this.panel3.Controls.Add(this.flag_2);
            this.panel3.Controls.Add(this.daalFav_button);
            this.panel3.Controls.Add(this.daal_button);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(0, 406);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(856, 203);
            this.panel3.TabIndex = 7;
            // 
            // daal_Rating
            // 
            this.daal_Rating.BackColor = System.Drawing.Color.Transparent;
            this.daal_Rating.Enabled = false;
            this.daal_Rating.ForeColor = System.Drawing.Color.Yellow;
            this.daal_Rating.Location = new System.Drawing.Point(429, 32);
            this.daal_Rating.Name = "daal_Rating";
            this.daal_Rating.Size = new System.Drawing.Size(170, 26);
            this.daal_Rating.TabIndex = 13;
            this.daal_Rating.Value = 0;
            // 
            // L_2
            // 
            this.L_2.AutoSize = true;
            this.L_2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_2.ForeColor = System.Drawing.Color.Red;
            this.L_2.Location = new System.Drawing.Point(694, 137);
            this.L_2.Name = "L_2";
            this.L_2.Size = new System.Drawing.Size(131, 15);
            this.L_2.TabIndex = 12;
            this.L_2.Text = " Added To Favorites!";
            this.L_2.Visible = false;
            // 
            // flag_2
            // 
            this.flag_2.AutoSize = true;
            this.flag_2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_2.ForeColor = System.Drawing.Color.Red;
            this.flag_2.Location = new System.Drawing.Point(677, 117);
            this.flag_2.Name = "flag_2";
            this.flag_2.Size = new System.Drawing.Size(166, 20);
            this.flag_2.TabIndex = 11;
            this.flag_2.Text = "Item Added To Cart!";
            this.flag_2.Visible = false;
            // 
            // daalFav_button
            // 
            this.daalFav_button.BackColor = System.Drawing.Color.White;
            this.daalFav_button.FlatAppearance.BorderSize = 0;
            this.daalFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.daalFav_button.Image = ((System.Drawing.Image)(resources.GetObject("daalFav_button.Image")));
            this.daalFav_button.Location = new System.Drawing.Point(15, 0);
            this.daalFav_button.Margin = new System.Windows.Forms.Padding(0);
            this.daalFav_button.Name = "daalFav_button";
            this.daalFav_button.Size = new System.Drawing.Size(39, 33);
            this.daalFav_button.TabIndex = 10;
            this.daalFav_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.daalFav_button.UseVisualStyleBackColor = false;
            this.daalFav_button.Click += new System.EventHandler(this.daalFav_button_Click);
            // 
            // daal_button
            // 
            this.daal_button.BackColor = System.Drawing.Color.White;
            this.daal_button.FlatAppearance.BorderSize = 0;
            this.daal_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.daal_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.daal_button.ForeColor = System.Drawing.Color.Gold;
            this.daal_button.Location = new System.Drawing.Point(713, 28);
            this.daal_button.Name = "daal_button";
            this.daal_button.Size = new System.Drawing.Size(130, 35);
            this.daal_button.TabIndex = 8;
            this.daal_button.Text = "Add To Cart";
            this.daal_button.UseVisualStyleBackColor = false;
            this.daal_button.Click += new System.EventHandler(this.daal_button_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(731, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 30);
            this.label6.TabIndex = 7;
            this.label6.Text = "Rs. 150";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(299, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 35);
            this.label7.TabIndex = 6;
            this.label7.Text = "Daal Mix";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::Foodie_menu.Resource1.daal;
            this.pictureBox3.Location = new System.Drawing.Point(73, 28);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(220, 157);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.roast_Rating);
            this.panel4.Controls.Add(this.L_3);
            this.panel4.Controls.Add(this.flag_3);
            this.panel4.Controls.Add(this.roastFav_button);
            this.panel4.Controls.Add(this.roast_button);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(0, 609);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(856, 203);
            this.panel4.TabIndex = 8;
            // 
            // roast_Rating
            // 
            this.roast_Rating.BackColor = System.Drawing.Color.Transparent;
            this.roast_Rating.Enabled = false;
            this.roast_Rating.ForeColor = System.Drawing.Color.Yellow;
            this.roast_Rating.Location = new System.Drawing.Point(503, 27);
            this.roast_Rating.Name = "roast_Rating";
            this.roast_Rating.Size = new System.Drawing.Size(170, 26);
            this.roast_Rating.TabIndex = 13;
            this.roast_Rating.Value = 0;
            // 
            // L_3
            // 
            this.L_3.AutoSize = true;
            this.L_3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_3.ForeColor = System.Drawing.Color.Red;
            this.L_3.Location = new System.Drawing.Point(694, 132);
            this.L_3.Name = "L_3";
            this.L_3.Size = new System.Drawing.Size(131, 15);
            this.L_3.TabIndex = 12;
            this.L_3.Text = " Added To Favorites!";
            this.L_3.Visible = false;
            // 
            // flag_3
            // 
            this.flag_3.AutoSize = true;
            this.flag_3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_3.ForeColor = System.Drawing.Color.Red;
            this.flag_3.Location = new System.Drawing.Point(677, 112);
            this.flag_3.Name = "flag_3";
            this.flag_3.Size = new System.Drawing.Size(166, 20);
            this.flag_3.TabIndex = 11;
            this.flag_3.Text = "Item Added To Cart!";
            this.flag_3.Visible = false;
            // 
            // roastFav_button
            // 
            this.roastFav_button.BackColor = System.Drawing.Color.White;
            this.roastFav_button.FlatAppearance.BorderSize = 0;
            this.roastFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.roastFav_button.Image = ((System.Drawing.Image)(resources.GetObject("roastFav_button.Image")));
            this.roastFav_button.Location = new System.Drawing.Point(15, 0);
            this.roastFav_button.Margin = new System.Windows.Forms.Padding(0);
            this.roastFav_button.Name = "roastFav_button";
            this.roastFav_button.Size = new System.Drawing.Size(39, 33);
            this.roastFav_button.TabIndex = 10;
            this.roastFav_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.roastFav_button.UseVisualStyleBackColor = false;
            this.roastFav_button.Click += new System.EventHandler(this.roastFav_button_Click);
            // 
            // roast_button
            // 
            this.roast_button.BackColor = System.Drawing.Color.White;
            this.roast_button.FlatAppearance.BorderSize = 0;
            this.roast_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.roast_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roast_button.ForeColor = System.Drawing.Color.Gold;
            this.roast_button.Location = new System.Drawing.Point(713, 27);
            this.roast_button.Name = "roast_button";
            this.roast_button.Size = new System.Drawing.Size(130, 35);
            this.roast_button.TabIndex = 8;
            this.roast_button.Text = "Add To Cart";
            this.roast_button.UseVisualStyleBackColor = false;
            this.roast_button.Click += new System.EventHandler(this.roast_button_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gold;
            this.label9.Location = new System.Drawing.Point(731, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 30);
            this.label9.TabIndex = 7;
            this.label9.Text = "Rs. 300";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(299, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(198, 35);
            this.label10.TabIndex = 6;
            this.label10.Text = "Chicken Roast";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = global::Foodie_menu.Resource1.roast;
            this.pictureBox4.Location = new System.Drawing.Point(73, 23);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(220, 157);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.haleem_Rating);
            this.panel5.Controls.Add(this.L_5);
            this.panel5.Controls.Add(this.flag_5);
            this.panel5.Controls.Add(this.haleemFav_button);
            this.panel5.Controls.Add(this.haleem_button);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel5.Location = new System.Drawing.Point(0, 812);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(856, 203);
            this.panel5.TabIndex = 9;
            // 
            // haleem_Rating
            // 
            this.haleem_Rating.BackColor = System.Drawing.Color.Transparent;
            this.haleem_Rating.Enabled = false;
            this.haleem_Rating.ForeColor = System.Drawing.Color.Yellow;
            this.haleem_Rating.Location = new System.Drawing.Point(419, 29);
            this.haleem_Rating.Name = "haleem_Rating";
            this.haleem_Rating.Size = new System.Drawing.Size(170, 26);
            this.haleem_Rating.TabIndex = 14;
            this.haleem_Rating.Value = 0;
            // 
            // L_5
            // 
            this.L_5.AutoSize = true;
            this.L_5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_5.ForeColor = System.Drawing.Color.Red;
            this.L_5.Location = new System.Drawing.Point(694, 137);
            this.L_5.Name = "L_5";
            this.L_5.Size = new System.Drawing.Size(131, 15);
            this.L_5.TabIndex = 13;
            this.L_5.Text = " Added To Favorites!";
            this.L_5.Visible = false;
            // 
            // flag_5
            // 
            this.flag_5.AutoSize = true;
            this.flag_5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_5.ForeColor = System.Drawing.Color.Red;
            this.flag_5.Location = new System.Drawing.Point(677, 117);
            this.flag_5.Name = "flag_5";
            this.flag_5.Size = new System.Drawing.Size(166, 20);
            this.flag_5.TabIndex = 12;
            this.flag_5.Text = "Item Added To Cart!";
            this.flag_5.Visible = false;
            // 
            // haleemFav_button
            // 
            this.haleemFav_button.BackColor = System.Drawing.Color.White;
            this.haleemFav_button.FlatAppearance.BorderSize = 0;
            this.haleemFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.haleemFav_button.Image = ((System.Drawing.Image)(resources.GetObject("haleemFav_button.Image")));
            this.haleemFav_button.Location = new System.Drawing.Point(15, 0);
            this.haleemFav_button.Margin = new System.Windows.Forms.Padding(0);
            this.haleemFav_button.Name = "haleemFav_button";
            this.haleemFav_button.Size = new System.Drawing.Size(39, 33);
            this.haleemFav_button.TabIndex = 10;
            this.haleemFav_button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.haleemFav_button.UseVisualStyleBackColor = false;
            this.haleemFav_button.Click += new System.EventHandler(this.haleemFav_button_Click);
            // 
            // haleem_button
            // 
            this.haleem_button.BackColor = System.Drawing.Color.White;
            this.haleem_button.FlatAppearance.BorderSize = 0;
            this.haleem_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.haleem_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.haleem_button.ForeColor = System.Drawing.Color.Gold;
            this.haleem_button.Location = new System.Drawing.Point(713, 29);
            this.haleem_button.Name = "haleem_button";
            this.haleem_button.Size = new System.Drawing.Size(130, 35);
            this.haleem_button.TabIndex = 8;
            this.haleem_button.Text = "Add To Cart";
            this.haleem_button.UseVisualStyleBackColor = false;
            this.haleem_button.Click += new System.EventHandler(this.haleem_button_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gold;
            this.label11.Location = new System.Drawing.Point(731, 67);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 30);
            this.label11.TabIndex = 7;
            this.label11.Text = "Rs. 200";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft JhengHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(299, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(114, 35);
            this.label12.TabIndex = 6;
            this.label12.Text = "Haleem";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::Foodie_menu.Resource1.haleem;
            this.pictureBox5.Location = new System.Drawing.Point(73, 25);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(220, 157);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // homeFood1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "homeFood1";
            this.Size = new System.Drawing.Size(856, 488);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button pulao_buttton;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button karahi_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button daal_button;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button roast_button;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button haleem_button;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button karahiFav_button;
        private System.Windows.Forms.Button daalFav_button;
        private System.Windows.Forms.Button roastFav_button;
        private System.Windows.Forms.Button haleemFav_button;
        private System.Windows.Forms.Label flag_1;
        private System.Windows.Forms.Label flag_4;
        private System.Windows.Forms.Label flag_2;
        private System.Windows.Forms.Label flag_3;
        private System.Windows.Forms.Label flag_5;
        private System.Windows.Forms.Label L_1;
        private System.Windows.Forms.Label L_4;
        private System.Windows.Forms.Label L_2;
        private System.Windows.Forms.Label L_3;
        private System.Windows.Forms.Label L_5;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button pulaoFav_button;
        private Bunifu.Framework.UI.BunifuRating pulao_Rating;
        private Bunifu.Framework.UI.BunifuRating karahi_Rating;
        private Bunifu.Framework.UI.BunifuRating daal_Rating;
        private Bunifu.Framework.UI.BunifuRating roast_Rating;
        private Bunifu.Framework.UI.BunifuRating haleem_Rating;
    }
}
