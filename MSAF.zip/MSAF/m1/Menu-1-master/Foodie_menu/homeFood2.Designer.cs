﻿namespace Foodie_menu
{
    partial class homeFood2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(homeFood2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.flag_1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lungo_button = new System.Windows.Forms.Button();
            this.lungo_rating = new Bunifu.Framework.UI.BunifuRating();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.flag_2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.blackCoffee_button = new System.Windows.Forms.Button();
            this.blackcoffee_rating = new Bunifu.Framework.UI.BunifuRating();
            this.label5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.flag_3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.espresso_button = new System.Windows.Forms.Button();
            this.espresso_rating = new Bunifu.Framework.UI.BunifuRating();
            this.label8 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.flag_4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tea_button = new System.Windows.Forms.Button();
            this.tea_rating = new Bunifu.Framework.UI.BunifuRating();
            this.label10 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.flag_5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.mazagran_button = new System.Windows.Forms.Button();
            this.mazagran_rating = new Bunifu.Framework.UI.BunifuRating();
            this.label13 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.mazagranFav_button = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.teaFav_button = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.espressoFav_button = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.blackcoffeeFav_button = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lungoFav_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.flag_1);
            this.panel1.Controls.Add(this.lungoFav_button);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.lungo_button);
            this.panel1.Controls.Add(this.lungo_rating);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(924, 181);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // flag_1
            // 
            this.flag_1.AutoSize = true;
            this.flag_1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_1.ForeColor = System.Drawing.Color.Red;
            this.flag_1.Location = new System.Drawing.Point(732, 113);
            this.flag_1.Name = "flag_1";
            this.flag_1.Size = new System.Drawing.Size(64, 24);
            this.flag_1.TabIndex = 7;
            this.flag_1.Text = "Flag 1";
            this.flag_1.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(761, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 30);
            this.label7.TabIndex = 4;
            this.label7.Text = "Rs.150";
            // 
            // lungo_button
            // 
            this.lungo_button.BackColor = System.Drawing.Color.White;
            this.lungo_button.FlatAppearance.BorderSize = 0;
            this.lungo_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lungo_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lungo_button.ForeColor = System.Drawing.Color.Gold;
            this.lungo_button.Location = new System.Drawing.Point(736, 13);
            this.lungo_button.Name = "lungo_button";
            this.lungo_button.Size = new System.Drawing.Size(127, 34);
            this.lungo_button.TabIndex = 3;
            this.lungo_button.Text = "Add To Cart";
            this.lungo_button.UseVisualStyleBackColor = false;
            this.lungo_button.Click += new System.EventHandler(this.lungo_button_Click);
            // 
            // lungo_rating
            // 
            this.lungo_rating.BackColor = System.Drawing.Color.Transparent;
            this.lungo_rating.Enabled = false;
            this.lungo_rating.ForeColor = System.Drawing.Color.Gold;
            this.lungo_rating.Location = new System.Drawing.Point(398, 6);
            this.lungo_rating.Name = "lungo_rating";
            this.lungo_rating.Size = new System.Drawing.Size(164, 31);
            this.lungo_rating.TabIndex = 2;
            this.lungo_rating.Value = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(295, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lungo";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.flag_2);
            this.panel3.Controls.Add(this.blackcoffeeFav_button);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.blackCoffee_button);
            this.panel3.Controls.Add(this.blackcoffee_rating);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 181);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(924, 181);
            this.panel3.TabIndex = 8;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // flag_2
            // 
            this.flag_2.AutoSize = true;
            this.flag_2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_2.ForeColor = System.Drawing.Color.Red;
            this.flag_2.Location = new System.Drawing.Point(732, 112);
            this.flag_2.Name = "flag_2";
            this.flag_2.Size = new System.Drawing.Size(64, 24);
            this.flag_2.TabIndex = 7;
            this.flag_2.Text = "Flag 2";
            this.flag_2.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(761, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 30);
            this.label4.TabIndex = 4;
            this.label4.Text = "Rs.100";
            // 
            // blackCoffee_button
            // 
            this.blackCoffee_button.BackColor = System.Drawing.Color.White;
            this.blackCoffee_button.FlatAppearance.BorderSize = 0;
            this.blackCoffee_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.blackCoffee_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blackCoffee_button.ForeColor = System.Drawing.Color.Gold;
            this.blackCoffee_button.Location = new System.Drawing.Point(736, 15);
            this.blackCoffee_button.Name = "blackCoffee_button";
            this.blackCoffee_button.Size = new System.Drawing.Size(127, 34);
            this.blackCoffee_button.TabIndex = 3;
            this.blackCoffee_button.Text = "Add To Cart";
            this.blackCoffee_button.UseVisualStyleBackColor = false;
            this.blackCoffee_button.Click += new System.EventHandler(this.blackCoffee_button_Click);
            // 
            // blackcoffee_rating
            // 
            this.blackcoffee_rating.BackColor = System.Drawing.Color.Transparent;
            this.blackcoffee_rating.Enabled = false;
            this.blackcoffee_rating.ForeColor = System.Drawing.Color.Gold;
            this.blackcoffee_rating.Location = new System.Drawing.Point(478, 8);
            this.blackcoffee_rating.Name = "blackcoffee_rating";
            this.blackcoffee_rating.Size = new System.Drawing.Size(164, 31);
            this.blackcoffee_rating.TabIndex = 2;
            this.blackcoffee_rating.Value = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(294, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(192, 37);
            this.label5.TabIndex = 1;
            this.label5.Text = "Black Coffee";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.flag_3);
            this.panel4.Controls.Add(this.espressoFav_button);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.espresso_button);
            this.panel4.Controls.Add(this.espresso_rating);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.pictureBox3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 362);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(924, 181);
            this.panel4.TabIndex = 9;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // flag_3
            // 
            this.flag_3.AutoSize = true;
            this.flag_3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_3.ForeColor = System.Drawing.Color.Red;
            this.flag_3.Location = new System.Drawing.Point(732, 112);
            this.flag_3.Name = "flag_3";
            this.flag_3.Size = new System.Drawing.Size(64, 24);
            this.flag_3.TabIndex = 7;
            this.flag_3.Text = "Flag 3";
            this.flag_3.Visible = false;
            this.flag_3.Click += new System.EventHandler(this.flag_3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(761, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 30);
            this.label6.TabIndex = 4;
            this.label6.Text = "Rs.200";
            // 
            // espresso_button
            // 
            this.espresso_button.BackColor = System.Drawing.Color.White;
            this.espresso_button.FlatAppearance.BorderSize = 0;
            this.espresso_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.espresso_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.espresso_button.ForeColor = System.Drawing.Color.Gold;
            this.espresso_button.Location = new System.Drawing.Point(736, 10);
            this.espresso_button.Name = "espresso_button";
            this.espresso_button.Size = new System.Drawing.Size(127, 34);
            this.espresso_button.TabIndex = 3;
            this.espresso_button.Text = "Add To Cart";
            this.espresso_button.UseVisualStyleBackColor = false;
            this.espresso_button.Click += new System.EventHandler(this.espresso_button_Click);
            // 
            // espresso_rating
            // 
            this.espresso_rating.BackColor = System.Drawing.Color.Transparent;
            this.espresso_rating.Enabled = false;
            this.espresso_rating.ForeColor = System.Drawing.Color.Gold;
            this.espresso_rating.Location = new System.Drawing.Point(429, 6);
            this.espresso_rating.Name = "espresso_rating";
            this.espresso_rating.Size = new System.Drawing.Size(164, 31);
            this.espresso_rating.TabIndex = 2;
            this.espresso_rating.Value = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(295, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(141, 37);
            this.label8.TabIndex = 1;
            this.label8.Text = "Espresso";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.flag_4);
            this.panel5.Controls.Add(this.teaFav_button);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.tea_button);
            this.panel5.Controls.Add(this.tea_rating);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.pictureBox4);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 543);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(924, 181);
            this.panel5.TabIndex = 10;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // flag_4
            // 
            this.flag_4.AutoSize = true;
            this.flag_4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_4.ForeColor = System.Drawing.Color.Red;
            this.flag_4.Location = new System.Drawing.Point(732, 116);
            this.flag_4.Name = "flag_4";
            this.flag_4.Size = new System.Drawing.Size(64, 24);
            this.flag_4.TabIndex = 7;
            this.flag_4.Text = "Flag 4";
            this.flag_4.Visible = false;
            this.flag_4.Click += new System.EventHandler(this.flag_4_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gold;
            this.label9.Location = new System.Drawing.Point(761, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 30);
            this.label9.TabIndex = 4;
            this.label9.Text = "Rs.60";
            // 
            // tea_button
            // 
            this.tea_button.BackColor = System.Drawing.Color.White;
            this.tea_button.FlatAppearance.BorderSize = 0;
            this.tea_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.tea_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tea_button.ForeColor = System.Drawing.Color.Gold;
            this.tea_button.Location = new System.Drawing.Point(736, 10);
            this.tea_button.Name = "tea_button";
            this.tea_button.Size = new System.Drawing.Size(127, 34);
            this.tea_button.TabIndex = 3;
            this.tea_button.Text = "Add To Cart";
            this.tea_button.UseVisualStyleBackColor = false;
            this.tea_button.Click += new System.EventHandler(this.tea_button_Click);
            // 
            // tea_rating
            // 
            this.tea_rating.BackColor = System.Drawing.Color.Transparent;
            this.tea_rating.Enabled = false;
            this.tea_rating.ForeColor = System.Drawing.Color.Gold;
            this.tea_rating.Location = new System.Drawing.Point(357, 3);
            this.tea_rating.Name = "tea_rating";
            this.tea_rating.Size = new System.Drawing.Size(164, 31);
            this.tea_rating.TabIndex = 2;
            this.tea_rating.Value = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(295, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 37);
            this.label10.TabIndex = 1;
            this.label10.Text = "Tea";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.flag_5);
            this.panel6.Controls.Add(this.mazagranFav_button);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.mazagran_button);
            this.panel6.Controls.Add(this.mazagran_rating);
            this.panel6.Controls.Add(this.label13);
            this.panel6.Controls.Add(this.pictureBox5);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F);
            this.panel6.Location = new System.Drawing.Point(0, 724);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(924, 181);
            this.panel6.TabIndex = 11;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // flag_5
            // 
            this.flag_5.AutoSize = true;
            this.flag_5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flag_5.ForeColor = System.Drawing.Color.Red;
            this.flag_5.Location = new System.Drawing.Point(732, 117);
            this.flag_5.Name = "flag_5";
            this.flag_5.Size = new System.Drawing.Size(64, 24);
            this.flag_5.TabIndex = 7;
            this.flag_5.Text = "Flag 5";
            this.flag_5.Visible = false;
            this.flag_5.Click += new System.EventHandler(this.flag_5_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Microsoft JhengHei UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gold;
            this.label12.Location = new System.Drawing.Point(761, 47);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 30);
            this.label12.TabIndex = 4;
            this.label12.Text = "Rs.180";
            // 
            // mazagran_button
            // 
            this.mazagran_button.BackColor = System.Drawing.Color.White;
            this.mazagran_button.FlatAppearance.BorderSize = 0;
            this.mazagran_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.mazagran_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mazagran_button.ForeColor = System.Drawing.Color.Gold;
            this.mazagran_button.Location = new System.Drawing.Point(736, 10);
            this.mazagran_button.Name = "mazagran_button";
            this.mazagran_button.Size = new System.Drawing.Size(127, 34);
            this.mazagran_button.TabIndex = 3;
            this.mazagran_button.Text = "Add To Cart";
            this.mazagran_button.UseVisualStyleBackColor = false;
            this.mazagran_button.Click += new System.EventHandler(this.mazagran_button_Click);
            // 
            // mazagran_rating
            // 
            this.mazagran_rating.BackColor = System.Drawing.Color.Transparent;
            this.mazagran_rating.Enabled = false;
            this.mazagran_rating.ForeColor = System.Drawing.Color.Gold;
            this.mazagran_rating.Location = new System.Drawing.Point(440, 3);
            this.mazagran_rating.Name = "mazagran_rating";
            this.mazagran_rating.Size = new System.Drawing.Size(179, 31);
            this.mazagran_rating.TabIndex = 2;
            this.mazagran_rating.Value = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label13.Font = new System.Drawing.Font("Microsoft JhengHei UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(295, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(156, 37);
            this.label13.TabIndex = 1;
            this.label13.Text = "Mazagran";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // mazagranFav_button
            // 
            this.mazagranFav_button.BackColor = System.Drawing.Color.White;
            this.mazagranFav_button.FlatAppearance.BorderSize = 0;
            this.mazagranFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mazagranFav_button.Image = ((System.Drawing.Image)(resources.GetObject("mazagranFav_button.Image")));
            this.mazagranFav_button.Location = new System.Drawing.Point(17, 3);
            this.mazagranFav_button.Name = "mazagranFav_button";
            this.mazagranFav_button.Size = new System.Drawing.Size(31, 30);
            this.mazagranFav_button.TabIndex = 5;
            this.mazagranFav_button.UseVisualStyleBackColor = false;
            this.mazagranFav_button.Click += new System.EventHandler(this.mazagranFav_button_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Foodie_menu.Resource1.mazaagran;
            this.pictureBox5.Location = new System.Drawing.Point(54, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(235, 181);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // teaFav_button
            // 
            this.teaFav_button.BackColor = System.Drawing.Color.White;
            this.teaFav_button.FlatAppearance.BorderSize = 0;
            this.teaFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.teaFav_button.Image = ((System.Drawing.Image)(resources.GetObject("teaFav_button.Image")));
            this.teaFav_button.Location = new System.Drawing.Point(17, 0);
            this.teaFav_button.Name = "teaFav_button";
            this.teaFav_button.Size = new System.Drawing.Size(31, 30);
            this.teaFav_button.TabIndex = 5;
            this.teaFav_button.UseVisualStyleBackColor = false;
            this.teaFav_button.Click += new System.EventHandler(this.teaFav_button_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Foodie_menu.Resource1.tea;
            this.pictureBox4.Location = new System.Drawing.Point(54, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(235, 181);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // espressoFav_button
            // 
            this.espressoFav_button.BackColor = System.Drawing.Color.White;
            this.espressoFav_button.FlatAppearance.BorderSize = 0;
            this.espressoFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.espressoFav_button.Image = ((System.Drawing.Image)(resources.GetObject("espressoFav_button.Image")));
            this.espressoFav_button.Location = new System.Drawing.Point(17, 0);
            this.espressoFav_button.Name = "espressoFav_button";
            this.espressoFav_button.Size = new System.Drawing.Size(31, 30);
            this.espressoFav_button.TabIndex = 5;
            this.espressoFav_button.UseVisualStyleBackColor = false;
            this.espressoFav_button.Click += new System.EventHandler(this.espressoFav_button_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Foodie_menu.Resource1.lungo;
            this.pictureBox3.Location = new System.Drawing.Point(54, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(235, 181);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // blackcoffeeFav_button
            // 
            this.blackcoffeeFav_button.BackColor = System.Drawing.Color.White;
            this.blackcoffeeFav_button.FlatAppearance.BorderSize = 0;
            this.blackcoffeeFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.blackcoffeeFav_button.Image = ((System.Drawing.Image)(resources.GetObject("blackcoffeeFav_button.Image")));
            this.blackcoffeeFav_button.Location = new System.Drawing.Point(17, 0);
            this.blackcoffeeFav_button.Name = "blackcoffeeFav_button";
            this.blackcoffeeFav_button.Size = new System.Drawing.Size(31, 30);
            this.blackcoffeeFav_button.TabIndex = 5;
            this.blackcoffeeFav_button.UseVisualStyleBackColor = false;
            this.blackcoffeeFav_button.Click += new System.EventHandler(this.blackcoffeeFav_button_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Foodie_menu.Resource1.black_coffee;
            this.pictureBox2.Location = new System.Drawing.Point(54, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(235, 181);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // lungoFav_button
            // 
            this.lungoFav_button.BackColor = System.Drawing.Color.White;
            this.lungoFav_button.FlatAppearance.BorderSize = 0;
            this.lungoFav_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lungoFav_button.Image = ((System.Drawing.Image)(resources.GetObject("lungoFav_button.Image")));
            this.lungoFav_button.Location = new System.Drawing.Point(17, 6);
            this.lungoFav_button.Name = "lungoFav_button";
            this.lungoFav_button.Size = new System.Drawing.Size(31, 30);
            this.lungoFav_button.TabIndex = 5;
            this.lungoFav_button.UseVisualStyleBackColor = false;
            this.lungoFav_button.Click += new System.EventHandler(this.lungoFav_button_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Foodie_menu.Resource1.lungo;
            this.pictureBox1.Location = new System.Drawing.Point(54, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(235, 181);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // homeFood2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "homeFood2";
            this.Size = new System.Drawing.Size(924, 476);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label flag_1;
        private System.Windows.Forms.Button lungoFav_button;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button lungo_button;
        private Bunifu.Framework.UI.BunifuRating lungo_rating;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label flag_2;
        private System.Windows.Forms.Button blackcoffeeFav_button;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button blackCoffee_button;
        private Bunifu.Framework.UI.BunifuRating blackcoffee_rating;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label flag_3;
        private System.Windows.Forms.Button espressoFav_button;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button espresso_button;
        private Bunifu.Framework.UI.BunifuRating espresso_rating;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label flag_4;
        private System.Windows.Forms.Button teaFav_button;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button tea_button;
        private Bunifu.Framework.UI.BunifuRating tea_rating;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label flag_5;
        private System.Windows.Forms.Button mazagranFav_button;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button mazagran_button;
        private Bunifu.Framework.UI.BunifuRating mazagran_rating;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Timer timer1;
    }
}
