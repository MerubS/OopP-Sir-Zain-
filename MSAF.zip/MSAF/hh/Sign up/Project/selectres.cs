﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class selectres : UserControl
    {
        public selectres()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void foodieHub_button_Click(object sender, EventArgs e)
        {
            this.Hide();


        }

        private void ithaaChalet_button_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
