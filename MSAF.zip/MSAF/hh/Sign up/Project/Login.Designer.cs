﻿namespace Project
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Signup = new System.Windows.Forms.Panel();
            this.groupbox2 = new System.Windows.Forms.GroupBox();
            this.SSubmit = new System.Windows.Forms.Button();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.contact = new System.Windows.Forms.TextBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.address = new System.Windows.Forms.TextBox();
            this.cpass = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pass2 = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.email = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.username2 = new System.Windows.Forms.TextBox();
            this.First = new System.Windows.Forms.GroupBox();
            this.Lsubmit = new System.Windows.Forms.Button();
            this.pass = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.username = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Signn = new System.Windows.Forms.Button();
            this.Logii = new System.Windows.Forms.Button();
            this.top1 = new Project.Top();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Signup.SuspendLayout();
            this.groupbox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.First.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(412, 497);
            this.panel1.TabIndex = 8;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Project.Resource1.Startup;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(412, 497);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Signup
            // 
            this.Signup.Controls.Add(this.groupbox2);
            this.Signup.Controls.Add(this.First);
            this.Signup.Controls.Add(this.panel3);
            this.Signup.Controls.Add(this.top1);
            this.Signup.Dock = System.Windows.Forms.DockStyle.Right;
            this.Signup.Location = new System.Drawing.Point(495, 0);
            this.Signup.Name = "Signup";
            this.Signup.Size = new System.Drawing.Size(430, 500);
            this.Signup.TabIndex = 21;
            this.Signup.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // groupbox2
            // 
            this.groupbox2.Controls.Add(this.SSubmit);
            this.groupbox2.Controls.Add(this.pictureBox8);
            this.groupbox2.Controls.Add(this.contact);
            this.groupbox2.Controls.Add(this.pictureBox7);
            this.groupbox2.Controls.Add(this.address);
            this.groupbox2.Controls.Add(this.cpass);
            this.groupbox2.Controls.Add(this.pictureBox6);
            this.groupbox2.Controls.Add(this.pass2);
            this.groupbox2.Controls.Add(this.pictureBox5);
            this.groupbox2.Controls.Add(this.email);
            this.groupbox2.Controls.Add(this.pictureBox4);
            this.groupbox2.Controls.Add(this.username2);
            this.groupbox2.Location = new System.Drawing.Point(28, 147);
            this.groupbox2.Name = "groupbox2";
            this.groupbox2.Size = new System.Drawing.Size(303, 290);
            this.groupbox2.TabIndex = 14;
            this.groupbox2.TabStop = false;
            // 
            // SSubmit
            // 
            this.SSubmit.BackColor = System.Drawing.Color.Gold;
            this.SSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SSubmit.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SSubmit.ForeColor = System.Drawing.Color.White;
            this.SSubmit.Location = new System.Drawing.Point(166, 247);
            this.SSubmit.Name = "SSubmit";
            this.SSubmit.Size = new System.Drawing.Size(116, 26);
            this.SSubmit.TabIndex = 25;
            this.SSubmit.Text = "Submit";
            this.SSubmit.UseVisualStyleBackColor = false;
            this.SSubmit.Click += new System.EventHandler(this.Back_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Project.Resource1.phone2;
            this.pictureBox8.Location = new System.Drawing.Point(42, 221);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(22, 20);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 18;
            this.pictureBox8.TabStop = false;
            // 
            // contact
            // 
            this.contact.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contact.ForeColor = System.Drawing.Color.Silver;
            this.contact.Location = new System.Drawing.Point(82, 219);
            this.contact.Name = "contact";
            this.contact.Size = new System.Drawing.Size(161, 22);
            this.contact.TabIndex = 17;
            this.contact.Text = "Contact";
            this.contact.Enter += new System.EventHandler(this.contact_Enter);
            this.contact.Leave += new System.EventHandler(this.contact_Leave);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Project.Resource1.home2;
            this.pictureBox7.Location = new System.Drawing.Point(42, 184);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(22, 20);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 16;
            this.pictureBox7.TabStop = false;
            // 
            // address
            // 
            this.address.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.ForeColor = System.Drawing.Color.Silver;
            this.address.Location = new System.Drawing.Point(82, 182);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(161, 22);
            this.address.TabIndex = 15;
            this.address.Text = "Address";
            this.address.Enter += new System.EventHandler(this.address_Enter);
            this.address.Leave += new System.EventHandler(this.address_Leave);
            // 
            // cpass
            // 
            this.cpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpass.ForeColor = System.Drawing.Color.Silver;
            this.cpass.Location = new System.Drawing.Point(82, 145);
            this.cpass.Name = "cpass";
            this.cpass.Size = new System.Drawing.Size(161, 22);
            this.cpass.TabIndex = 14;
            this.cpass.Text = "Confirm Password";
            this.cpass.Enter += new System.EventHandler(this.cpass_Enter);
            this.cpass.Leave += new System.EventHandler(this.cpass_Leave);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Project.Resource1.pass2;
            this.pictureBox6.Location = new System.Drawing.Point(42, 104);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(22, 20);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 13;
            this.pictureBox6.TabStop = false;
            // 
            // pass2
            // 
            this.pass2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass2.ForeColor = System.Drawing.Color.Silver;
            this.pass2.Location = new System.Drawing.Point(82, 104);
            this.pass2.Name = "pass2";
            this.pass2.Size = new System.Drawing.Size(161, 22);
            this.pass2.TabIndex = 12;
            this.pass2.Text = "Password";
            this.pass2.Enter += new System.EventHandler(this.pass2_Enter);
            this.pass2.Leave += new System.EventHandler(this.pass2_Leave);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Project.Resource1.email2;
            this.pictureBox5.Location = new System.Drawing.Point(42, 63);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(22, 20);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 11;
            this.pictureBox5.TabStop = false;
            // 
            // email
            // 
            this.email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Silver;
            this.email.Location = new System.Drawing.Point(82, 61);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(161, 22);
            this.email.TabIndex = 7;
            this.email.Text = "someone@example.com";
            this.email.Enter += new System.EventHandler(this.email_Enter);
            this.email.Leave += new System.EventHandler(this.email_Leave);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Project.Resource1.user2;
            this.pictureBox4.Location = new System.Drawing.Point(42, 28);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(22, 20);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // username2
            // 
            this.username2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username2.ForeColor = System.Drawing.Color.Silver;
            this.username2.Location = new System.Drawing.Point(82, 28);
            this.username2.Name = "username2";
            this.username2.Size = new System.Drawing.Size(161, 22);
            this.username2.TabIndex = 1;
            this.username2.Text = "Username";
            this.username2.Enter += new System.EventHandler(this.username2_Enter);
            this.username2.Leave += new System.EventHandler(this.username2_Leave);
            // 
            // First
            // 
            this.First.Controls.Add(this.Lsubmit);
            this.First.Controls.Add(this.pass);
            this.First.Controls.Add(this.pictureBox3);
            this.First.Controls.Add(this.username);
            this.First.Controls.Add(this.pictureBox2);
            this.First.Controls.Add(this.label1);
            this.First.Location = new System.Drawing.Point(28, 181);
            this.First.Name = "First";
            this.First.Size = new System.Drawing.Size(303, 195);
            this.First.TabIndex = 25;
            this.First.TabStop = false;
            // 
            // Lsubmit
            // 
            this.Lsubmit.BackColor = System.Drawing.Color.Gold;
            this.Lsubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Lsubmit.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lsubmit.ForeColor = System.Drawing.Color.White;
            this.Lsubmit.Location = new System.Drawing.Point(170, 149);
            this.Lsubmit.Name = "Lsubmit";
            this.Lsubmit.Size = new System.Drawing.Size(116, 26);
            this.Lsubmit.TabIndex = 26;
            this.Lsubmit.Text = "Submit";
            this.Lsubmit.UseVisualStyleBackColor = false;
            this.Lsubmit.Click += new System.EventHandler(this.Lsubmit_Click);
            // 
            // pass
            // 
            this.pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass.ForeColor = System.Drawing.Color.Silver;
            this.pass.Location = new System.Drawing.Point(93, 113);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(138, 22);
            this.pass.TabIndex = 13;
            this.pass.Text = "Password";
            this.pass.Enter += new System.EventHandler(this.pass_Enter);
            this.pass.Leave += new System.EventHandler(this.pass_Leave);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Project.Resource1.pass2;
            this.pictureBox3.Location = new System.Drawing.Point(51, 113);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(22, 20);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // username
            // 
            this.username.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.ForeColor = System.Drawing.Color.Silver;
            this.username.Location = new System.Drawing.Point(93, 68);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(138, 22);
            this.username.TabIndex = 11;
            this.username.Text = "Username";
            this.username.TextChanged += new System.EventHandler(this.username_TextChanged);
            this.username.Enter += new System.EventHandler(this.username_Enter);
            this.username.Leave += new System.EventHandler(this.username_Leave);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Project.Resource1.user2;
            this.pictureBox2.Location = new System.Drawing.Point(51, 68);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(22, 20);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(280, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "Welcome Back. Please log in to your account.";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.Signn);
            this.panel3.Controls.Add(this.Logii);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 427);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(430, 73);
            this.panel3.TabIndex = 25;
            // 
            // Signn
            // 
            this.Signn.BackColor = System.Drawing.Color.Gold;
            this.Signn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Signn.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signn.ForeColor = System.Drawing.Color.White;
            this.Signn.Location = new System.Drawing.Point(208, 11);
            this.Signn.Name = "Signn";
            this.Signn.Size = new System.Drawing.Size(92, 36);
            this.Signn.TabIndex = 24;
            this.Signn.Text = "Sign Up";
            this.Signn.UseVisualStyleBackColor = false;
            this.Signn.Click += new System.EventHandler(this.Signn_Click);
            // 
            // Logii
            // 
            this.Logii.BackColor = System.Drawing.Color.Gold;
            this.Logii.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Logii.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Logii.ForeColor = System.Drawing.Color.White;
            this.Logii.Location = new System.Drawing.Point(70, 11);
            this.Logii.Name = "Logii";
            this.Logii.Size = new System.Drawing.Size(92, 36);
            this.Logii.TabIndex = 23;
            this.Logii.Text = "Login";
            this.Logii.UseVisualStyleBackColor = false;
            this.Logii.Click += new System.EventHandler(this.Logii_Click);
            // 
            // top1
            // 
            this.top1.Dock = System.Windows.Forms.DockStyle.Top;
            this.top1.Location = new System.Drawing.Point(0, 0);
            this.top1.Name = "top1";
            this.top1.Size = new System.Drawing.Size(430, 152);
            this.top1.TabIndex = 0;
            this.top1.Load += new System.EventHandler(this.top1_Load);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(925, 500);
            this.Controls.Add(this.Signup);
            this.Controls.Add(this.panel1);
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Signup.ResumeLayout(false);
            this.groupbox2.ResumeLayout(false);
            this.groupbox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.First.ResumeLayout(false);
            this.First.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel Signup;
        private Top top1;
        private System.Windows.Forms.Button Logii;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Signn;
        private System.Windows.Forms.GroupBox First;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupbox2;
        private System.Windows.Forms.TextBox pass;
        private System.Windows.Forms.TextBox username2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox pass2;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox cpass;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.TextBox contact;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Button SSubmit;
        private System.Windows.Forms.Button Lsubmit;
    }
}

