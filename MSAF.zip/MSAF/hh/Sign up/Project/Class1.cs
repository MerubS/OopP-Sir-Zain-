﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    public class UserInfo
   {
        string name, address, num, pass, email;
        int f = 0;
        bool privelege;

        public string _name
        {
            set {name = value;}
            get { return name; }
        }
        public string _address
        {
            set { address = value; }
            get { return address; }
        }
        public string _password
        {
           
            get { return pass; }
        }
        public string _number
        {
            set { num = value; }
            get { return num; }
        }
        public string _email
        {
            
            get { return email; }
        }
        public UserInfo()
        {
            name = "**";
            address = "**";
            num = "**";
            pass = "**";
            email = "**";
        }

      

        public void signup(string a, string b, string c, string d, string e)
        {
            name = a;
            address = b;
            num = c;
            email = e;
            if (d.Length >= 8)
            {
                pass = d;
              
            }
            else { Console.WriteLine("Password not valid"); }
            
         }

        
    }
        
    public class Serialize
    {
        public void SNow(UserInfo a)
        {
            Stream s = File.Open("user.txt", FileMode.OpenOrCreate);
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(s, a);
            s.Close();
        }

        public UserInfo DNow()
        {
            UserInfo a;
            Stream s = File.Open("user.txt", FileMode.Open);
            BinaryFormatter b = new BinaryFormatter();
            a = (UserInfo)b.Deserialize(s);
            s.Close();
            return a;
        }
    }
            

    }

